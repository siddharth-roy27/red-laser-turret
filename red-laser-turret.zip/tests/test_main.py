def test_imports():
    import src.vision as v
    import src.turret_controller as t
    import src.trajectory as b
    assert True
